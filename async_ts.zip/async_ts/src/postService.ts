export async function fetchPosts(filter = '', currentPage: number, pageSize: number) {
     const url = `https://jsonplaceholder.typicode.com/posts?_page=${currentPage}&_limit=${pageSize}&title_like=${filter}`;
     const response = await fetch(url);
     const posts = await response.json();
     return posts;
}
    
export async function fetchUser(userId: number) {
     const url = `https://jsonplaceholder.typicode.com/users/${userId}`;
     const response = await fetch(url);
     const user = await response.json();
     return user;
}
    
export function renderPosts(posts: any[], postsContainer: HTMLElement) {
     posts.forEach(post => renderPost(post, postsContainer)); 
}
    
async function renderPost(post: any, postsContainer: HTMLElement) { 
     const user = await fetchUser(post.userId);
     const postElement = document.createElement('div');
     postElement.className = 'post';
     postElement.innerHTML = `
      <h2>${post.title}</h2>
      <p>${post.body}</p>
      <div class="user">
       <h3>${user.name}</h3>
       <p>${user.email}</p>
       <p>${user.phone}</p>
      </div>
     `;
     postsContainer.appendChild(postElement);
}
