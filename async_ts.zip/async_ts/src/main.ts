import { debounce } from './utils';
import { fetchPosts, fetchUser, renderPosts } from './postService';

const postsContainer = document.getElementById('posts')!;
const filterInput = document.getElementById('filter') as HTMLInputElement;
const PAGE_SIZE = 10;
let currentPage = 1;
let isLoading = false;
let hasMorePosts = true;

filterInput.addEventListener('input', debounce(async (event: Event) => {
 const filter = encodeURIComponent((event.target as HTMLInputElement).value);
 currentPage = 1;
 hasMorePosts = true;
 postsContainer.innerHTML = '';
 const posts = await fetchPosts(filter, currentPage, PAGE_SIZE);
 renderPosts(posts, postsContainer); 
}, 500));

window.addEventListener('scroll', async () => {
 const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
 if (scrollTop + clientHeight >= scrollHeight - 5 && !isLoading && hasMorePosts) {
  isLoading = true;
  currentPage++;
  const posts = await fetchPosts(encodeURIComponent(filterInput.value), currentPage, PAGE_SIZE);
  renderPosts(posts, postsContainer); 
  isLoading = false;
  hasMorePosts = posts.length === PAGE_SIZE;
 }
});

fetchPosts('', currentPage, PAGE_SIZE).then(posts => renderPosts(posts, postsContainer)); 