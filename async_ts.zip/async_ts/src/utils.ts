export function debounce<T extends (...args: any[]) => any>(func: T, delay: number) {
   let timeoutId: ReturnType<typeof setTimeout>;
   return function (this: Window, ...args: Parameters<T>) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(this, args), delay);
   };
}
